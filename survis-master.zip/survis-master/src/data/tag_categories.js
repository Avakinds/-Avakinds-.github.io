const userDefinedTagCategories = {
	"type": {
		"description": "type of the paper"
	}
}